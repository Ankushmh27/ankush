package basicScript;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.awt.AWTException;
import java.awt.RenderingHints.Key;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class TruemedsApp {
    
    @SuppressWarnings({ "deprecation" })
	@Test
    public void TMApp() throws MalformedURLException, InterruptedException, AWTException{
		
        // Set up desired capabilities
        DesiredCapabilities capabilities = new DesiredCapabilities();
        AndroidDriver driver;
        
		UiAutomator2Options options = new UiAutomator2Options();
		options.setPlatformName("Android");
		options.setApp("C:\\Users\\ankus\\Downloads\\v7.7.0(791)_stageQARelease_Truemeds.apk");
		options.setAutomationName("UiAutomator2");
		options.setDeviceName("emulator-5554");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(100000));
		
		
		WebDriverWait wait = new  WebDriverWait(driver, Duration.ofMillis(2000));
		WebElement allowButton = driver.findElement(By.xpath("//android.widget.Button[@resource-id=\"com.android.permissioncontroller:id/permission_allow_button\"]"));
		wait.until(ExpectedConditions.visibilityOf(allowButton));
		allowButton.click();	
		
		Thread.sleep(1000);
		WebElement mobileNumber= driver.findElement(By.xpath("//android.widget.EditText[@resource-id=\"com.intellihealth.truemeds:id/etInputField\"]"));
		mobileNumber.sendKeys("9999999999");
		
		WebElement getOTP = driver.findElement(
				By.xpath("//android.view.ViewGroup[@resource-id=\"com.intellihealth.truemeds:id/btnGetOtp\"]"));
		getOTP.click();

		//OTP input field 
	    driver.findElement(By.xpath("//android.widget.EditText[@resource-id=\"com.intellihealth.truemeds:id/etOtp1\"]"))
				.sendKeys("1");
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id=\"com.intellihealth.truemeds:id/etOtp2\"]"))
				.sendKeys("1");
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id=\"com.intellihealth.truemeds:id/etOtp3\"]"))
				.sendKeys("1");
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id=\"com.intellihealth.truemeds:id/etOtp4\"]"))
				.sendKeys("1");
		
		WebElement cancel_choose_ur_Location = driver.findElement(By.xpath("//android.widget.ImageView[@resource-id=\"com.intellihealth.truemeds:id/imageClose\"]"));
		cancel_choose_ur_Location.click();
		
		WebElement serachBox = driver.findElement(By.xpath("//android.widget.EditText[@resource-id=\"com.intellihealth.truemeds:id/etSearch\"]"));
		wait.until(ExpectedConditions.visibilityOf(serachBox));
		serachBox.sendKeys("telma");
		Thread.sleep(1000);
		Robot robot = new Robot(); 
		robot.keyPress(KeyEvent.VK_ENTER); robot.keyRelease(KeyEvent.VK_ENTER);
		
		WebElement medName= driver.findElement(By.xpath("//android.widget.TextView[@resource-id=\"com.intellihealth.truemeds:id/tvSkuName\" and @text=\"Telma 40 Tablet 30\"]"));
		wait.until(ExpectedConditions.visibilityOf(medName));
		medName.click();
		
		
//		driver.close();
    }
}